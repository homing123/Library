using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(ButtonEx))]
public class Ed_ButtonEx : Editor
{
   
}
