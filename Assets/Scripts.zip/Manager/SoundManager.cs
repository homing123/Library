using UnityEngine;

public class SoundManager : Manager<SoundManager>
{
    AudioSource m_BGMSource;
    AudioSource m_EffectSource;

    private void Awake()
    {
        m_BGMSource = gameObject.AddComponent<AudioSource>();
        m_BGMSource.loop = true;
        m_EffectSource = gameObject.AddComponent<AudioSource>();
        m_EffectSource.loop = false;
    }
    public static AudioClip GetButtonClip()
    {
        return null;
    }
    public void Play_Sound(AudioClip clip)
    {
        m_EffectSource.PlayOneShot(clip);
    }
    public void Play_BGM(AudioClip clip)
    {
        m_BGMSource.Stop();
        m_BGMSource.clip = clip;
        m_BGMSource.Play();
    }
}
